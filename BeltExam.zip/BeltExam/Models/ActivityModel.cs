﻿using System.ComponentModel.DataAnnotations;
using BeltExam.Data;

namespace BeltExam.Models
{
    public class ActivityModel
    {
        [Key] public int ActivityId { get; set; }
        [Required(ErrorMessage = "Activity title is required")]
        public string Title { get; set; }
        public int Duration { get; set; }
        public string StringDuration { get; set; }

        public DateTime? Date { get; set; }
        [Required(ErrorMessage = "Activity description is required")]
        public string Description { get; set; }
        public int UserId { get; set; }
        public User? User { get; set; }
        public ICollection<ActivityParticipants>? Participants  { get; set; }
        public int count { get; set; }
        public string action { get; set; }
        public string Joinaction { get; set; }

        public string UserName { get; set; }
    }
}
