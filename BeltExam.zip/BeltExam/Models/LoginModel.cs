﻿using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace BeltExam.Models
{
    public class LoginModel
    {
        [Key] public int id { get; set; }
        [Required, EmailAddress, Display(Name = "Email")]
        public string LoginEmail { get; set; }

        [Required, DataType(DataType.Password), Display(Name = "Password")]
        public string Password { get; set; }

    }
}
