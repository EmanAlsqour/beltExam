﻿using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace BeltExam.Models
{
    public class RegisterModel
    {
        [Key] public int Id { get; set; }
        [Required, Display(Name = "Name")]
        [MinLength(2, ErrorMessage = "First Name must be at least 2 characters.")]
        public string Name { get; set; }


        [Required, EmailAddress, RegularExpression(@"^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$",ErrorMessage = "The Email field is not a valid e-mail address.")]
        public string Email { get; set; }

        [Required, DataType(DataType.Password) , RegularExpression(@"^(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$" , ErrorMessage = "Password must be at least 8 characters contain at least 1 number, 1 letter, and a special character.")]
        //[MinLength(8, ErrorMessage = "Password must be at least 8 characters.")]
        public string Password { get; set; }

        [Required, DataType(DataType.Password), Display(Name = "Confirm Password")]
        [Compare("Password", ErrorMessage = "Password and confirmation must match.")]
        public string PasswordConfirmation { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.Now;
        public DateTime UpdatedAt { get; set; } = DateTime.Now;
    }
}
