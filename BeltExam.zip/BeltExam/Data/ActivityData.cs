﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace BeltExam.Data
{
    public class ActivityData
    {
        [Key] public int ActivityId { get; set; }
        public string Title { get; set; }
        public int Duration { get; set; }
        public string StringDuration { get; set; }
        public DateTime Date { get; set; }
        public string Description { get; set; }
        public int UserId { get; set; }
        public User User { get; set; }
        public ICollection<ActivityParticipants> Participants { get; set; }
    }
}
