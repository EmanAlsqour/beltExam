﻿using Microsoft.EntityFrameworkCore;
using System;
using BeltExam.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.VisualStudio.Web.CodeGenerators.Mvc.Razor;

namespace BeltExam.Data
{
    public class AppDbContext : DbContext
    {
        // base() calls the parent class' constructor passing the "options" parameter along
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<User> users { get; set; }
        public DbSet<ActivityData> Activities { get; set; }
        public DbSet<ActivityParticipants> ActivityParticipants { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            // add your own configuration here
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<ActivityParticipants>()
            .HasKey(t => new { t.ActivityId, t.UserId });

            modelBuilder.Entity<ActivityParticipants>()
           .HasOne(x => x.Activity)
           .WithMany(x => x.Participants)
           .HasForeignKey(t => t.ActivityId)
           .OnDelete(DeleteBehavior.ClientCascade);


             modelBuilder.Entity<ActivityParticipants>()
             .HasOne(x => x.User)
             .WithMany(x => x.Participants)
             .HasForeignKey(t => t.UserId)
             .OnDelete(DeleteBehavior.ClientCascade);

        }
     
    }
}
