﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace BeltExam.Data
{
    public class ActivityParticipants
    {
        public int UserId { get; set; }
        public int ActivityId { get; set; }
        public User User { get; set; }
        public ActivityData Activity { get; set; }
    }
}
