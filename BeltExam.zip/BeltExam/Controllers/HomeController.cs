﻿#pragma warning disable CS8618
#nullable disable
using BeltExam.Data;
using BeltExam.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;
using System.Linq;
using System;

namespace BeltExam.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly AppDbContext _context;


        public HomeController(ILogger<HomeController> logger , AppDbContext context )
        {
            _logger = logger;
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }
        
        [HttpGet, Route("Register")]
        public IActionResult ShowRegistrationForm()
        {
            return View("Register");
        }

        [HttpPost, Route("Register")]
        public IActionResult Register(RegisterModel model)
        {
            if (ModelState.IsValid)
            {
                if (_context.users.Any(u => u.Email == model.Email))
                {
                    ViewBag.ErrorMessage = "Email already in use!";
                }
                else
                {
                    User newUser = new User
                    {
                        Name = model.Name,
                        Email = model.Email,
                        Password = model.Password,
                        CreatedAt = DateTime.Now,
                        UpdatedAt = DateTime.Now,
                    };
                    _context.Add(newUser);
                    _context.SaveChanges();

                    HttpContext.Session.SetString("UserName", newUser.Name );
                    HttpContext.Session.SetInt32("UserId", newUser.UserId);
                    return RedirectToAction("Dashboard");
                }
            }
            return View("Index");
        }
        [HttpGet, Route("/login")]
        public IActionResult Login()
        {
            return View("Login");
        }

        [HttpPost, Route("/login")]
        public IActionResult Login(LoginModel model)
        {
            if (ModelState.IsValid)
            {
                var existingUser = _context.users.SingleOrDefault(u => u.Email == model.LoginEmail);
                if (existingUser != null) // email found in DB
                {
                    if (existingUser.Password == model.Password) // password matches
                    {
                        HttpContext.Session.SetString("UserName", existingUser.Name);
                        HttpContext.Session.SetInt32("UserId", existingUser.UserId);
                        return RedirectToAction("Dashboard");

                    }
                    else
                    {
                        ViewBag.LoginErrorMessage = "Password does not match password in database.";
         
                    }
                }
                else
                {
  
                    ViewBag.LoginErrorMessage = "Email and password do not match";

                }
            }
            return View("Index");
        }
        [HttpGet, Route("/logout")]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index");
        }
        // [HttpGet]
        [HttpGet, Route("/Dashboard")]
        public IActionResult Dashboard()
        {
            ViewBag.UserId = (int?)HttpContext.Session.GetInt32("UserId");

            if (ViewBag.UserId == null)
            {
                return RedirectToAction("Index");
            }

            var allActivities = new List<ActivityModel>();
            var AllParticipant = _context.ActivityParticipants.ToList();
            int id = ViewBag.UserId;
            string action = "";
            string joinaction="";
            User ActiveUser = _context.users.FirstOrDefault(u => u.UserId == id);
            List<ActivityData> activitylist = _context.Activities.Include(p=>p.Participants)
                .ThenInclude(u=>u.User).Where(w => w.Date > DateTime.Now).OrderBy(w=>w.Date).ToList();
            if (activitylist?.Any() == true)
            {
                foreach (var item in activitylist)
                {
                    bool isParticipant = false;

                    User ActivityCreator = _context.users.FirstOrDefault(x => x.UserId == item.UserId);

                    List<ActivityParticipants> activityParticipants = _context.ActivityParticipants
                        .Where(x => x.ActivityId == item.ActivityId).ToList();
                    foreach (var par in activityParticipants)
                    {
                        if (par.UserId == id)
                        {
                            isParticipant = true; // not the creator 
                        }
                    }
                    if (item.UserId == id)
                    {
                        action = "Delete";
                        joinaction = "Delete";
                    }
                    else if (!isParticipant && item.UserId != id)
                    {
                        action = "Join";
                        joinaction = "Join";
                    }
                    else 
                    { 
                        action = "Leave";
                        joinaction = "Leave";
                    }
                 allActivities.Add(new ActivityModel()
                   {
                    UserId = item.UserId,
                    ActivityId = item.ActivityId,
                    Duration = item.Duration,
                    StringDuration = item.StringDuration,
                    Title = item.Title,
                    User = item.User,
                    Date = item.Date,
                    action = action,
                    Joinaction = joinaction,
                    UserName = ActivityCreator.Name,
                    count = _context.ActivityParticipants.Where(x => x.ActivityId == item.ActivityId).Count(),

                });
            }
        
        }
            return View(allActivities);
  }
        [HttpGet, Route("/AddActivity")]
        public IActionResult AddActivity()
        {
            ViewBag.UserId = (int?)HttpContext.Session.GetInt32("UserId");

            if (ViewBag.UserId == null)
            {
                return RedirectToAction("Index");
            }


            return View("AddActivity");
        }

        [HttpPost, Route("/AddActivity")]
        public  IActionResult AddActivity(ActivityModel model)
        {
            ViewBag.UserId = (int?)HttpContext.Session.GetInt32("UserId");
            User ActiveUser = _context.users.FirstOrDefault(u => u.UserId == HttpContext.Session.GetInt32("UserId"));

            if (ViewBag.UserId == null)
            {
                return RedirectToAction("Index");
            }
            if(model.Date < DateTime.Now)
            {
                ViewBag.ErrorMessage = "Activity date should be in future.";
                return View("AddActivity");

            }

            ActivityData ActivityData = new ActivityData()
            {
                UserId = ViewBag.UserId,
                Duration = model.Duration,
                StringDuration=model.StringDuration,
                Title = model.Title,
                Description=model.Description,  
                User = ActiveUser,  
                Date = (DateTime)model.Date,
                Participants=model.Participants,    
            };
            _context.Activities.Add(ActivityData);
            _context.SaveChanges();
            _context.users.Update(ActiveUser);
            return RedirectToAction("Details", new { activityId = ActivityData.ActivityId });
        }

        [HttpGet, Route("/details/{activityId}")]
        public async Task<IActionResult> Details(int activityId)
        {
            ViewBag.UserId = (int?)HttpContext.Session.GetInt32("UserId");

            if (ViewBag.UserId == null)
            {
                return RedirectToAction("Index");
            }
            string action = "";
            string joinaction = "";
            bool isParticipant =false;            
            ActivityData activityData = await _context.Activities.FindAsync(activityId);
            User ActivityCreator = _context.users.FirstOrDefault(x=>x.UserId == activityData.UserId);
            var selectedactivity = _context.Activities.Include(w => w.Participants).ThenInclude(g => g.User).AsNoTracking().Where(x => x.ActivityId == activityId).First();
            if (activityData != null)
            {
                         List<ActivityParticipants> activityParticipants = _context.ActivityParticipants.Where(x => x.ActivityId == activityId).ToList();
                        //User Creator = _context.users.FirstOrDefault(x => x.UserId == item.UserId);
                        foreach (var par in activityParticipants)
                        {
                            if (par.UserId == ViewBag.UserId)
                            {
                                isParticipant = true; // not the creator 
                            }
                        }
                        if (activityData.UserId == ViewBag.UserId)
                        {
                            joinaction = "Delete";
                        }

                        else if (isParticipant && activityData.UserId != ViewBag.UserId)
                        {

                            joinaction = "Leave";
                        }
                        else if (!isParticipant && activityData.UserId != ViewBag.UserId)
                        {
                            joinaction = "Join";
                        }

                    ActivityModel ModelData = new ActivityModel()
                {
                    UserId = activityData.UserId,
                    Duration = activityData.Duration,
                    Title = activityData.Title,
                    Description = activityData.Description,
                    Date = activityData.Date,
                    User= activityData.User, 
                    UserName=ActivityCreator.Name,
                    Joinaction = joinaction,
                    Participants = selectedactivity.Participants,
                    ActivityId= activityData.ActivityId,    
                };
                return View("Details", ModelData);

            }
            else
            {
                return RedirectToAction("AddActivity");
            }
        }
        [Route("/Delete/{activityId}")]

        public ActionResult Delete(int activityId)
        {
            User ActiveUser = _context.users.FirstOrDefault(u => u.UserId == HttpContext.Session.GetInt32("UserId"));
            List <ActivityParticipants > allParticipants = _context.ActivityParticipants.Where(x => x.ActivityId == activityId).ToList();
            if (ActiveUser == null)
            {
                return RedirectToAction("Index");
            }
            foreach (var Part in allParticipants)
            {
                _context.ActivityParticipants.Remove(Part);

            }
            _context.SaveChanges();
            ActivityData ToDelete = _context.Activities.FirstOrDefault(w => w.ActivityId == activityId);
            _context.Activities.Remove(ToDelete);
            _context.SaveChanges();
            return RedirectToAction("Dashboard");
        }
        [Route("/Join/{activityId}")]

        public IActionResult Join(int activityId)
        {
            var userID = (int?)HttpContext.Session.GetInt32("UserId");
            User user = _context.users.FirstOrDefault(u => u.UserId == userID);
            ActivityData activity = _context.Activities.FirstOrDefault(w => w.ActivityId == activityId);
            ActivityParticipants newParticipant = new ActivityParticipants();
            newParticipant.UserId = (int)userID;
            newParticipant.ActivityId = activityId;
            newParticipant.User = user;
            newParticipant.Activity = activity;
            _context.ActivityParticipants.Add(newParticipant);
            _context.SaveChanges();
            return RedirectToAction("Dashboard");
        }

        [Route("/Leave/{activityId}")]
        public IActionResult Leave(int activityId)
        {
            var userID = HttpContext.Session.GetInt32("UserId");
            ActivityParticipants ToDelete = _context.ActivityParticipants.FirstOrDefault(g => g.UserId == userID && g.ActivityId == activityId);
            _context.Remove(ToDelete);
            _context.SaveChanges();
            return RedirectToAction("Dashboard");
        }
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = System.Diagnostics.Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}